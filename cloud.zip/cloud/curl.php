<?php 

include('config.php');
function getCurl($url, $email, $apiToken) {
    $curl = curl_init();

    curl_setopt_array($curl, [
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "Content-Type: application/json",
        "X-Auth-Email: $email",
        "X-Auth-Key: $apiToken"
    ],
    ]);

        // Convert JSON array to PHP array
    $response = json_decode(curl_exec($curl));
    $err = curl_error($curl);

    curl_close($curl);
    if (!$response->success) {
        return $data = [
            'status' => 'error',
            'data' => $response->errors[0]->message
        ];
    } else if ($err) {
        return $data = [
            'status' => 'error',
            'data' => json_decode($err->errors)
        ];
    } else {
        return $data = [
            'status' => 'success',
            'data' => $response
        ];
    }
}

function postCurl($url, $param, $headers, $method) {
    $curl = curl_init();
    curl_setopt_array($curl, array(
    CURLOPT_URL => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => '',
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => $method,
    CURLOPT_POSTFIELDS => $param,
    CURLOPT_HTTPHEADER => $headers,
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        return $data = [
            'status' => 'error',
            'data' => "cURL Error #:" . $err
        ];
    } else {
        // Convert JSON array to PHP array
        return $data = [
            'status' => 'success',
            'data' => json_decode($response)
        ];
    }
}

?>