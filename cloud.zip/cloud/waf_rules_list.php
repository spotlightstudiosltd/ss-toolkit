<?php

include('config.php');
include('curl.php');

if (!empty($_POST['zoneId']) && !empty($_POST['zoneName'])) {
    
    $zoneId = $_POST['zoneId'];
    $email = $_POST['email'];
    $apiToken = $_POST['apiToken'];
    $url = "https://api.cloudflare.com/client/v4/zones/" . $zoneId . "/rulesets";
    $res = getCurl($url, $email, $apiToken);

    if ($res['status'] == 'error') {
        echo json_encode(['status' => false, 'output' => $res['data']]);
        die;
    }
    $rulesetList = $res['data']->result;

    $rulesArray = [];
    foreach($rulesetList as $key => $res) {
        // We need only this condition. Once is satisfied then proceed for next step.
        // given Kind & phase have permission for create rulesets
        if ($res->kind == 'zone' && $res->phase == 'http_request_firewall_custom') {
            $getUrl = 'https://api.cloudflare.com/client/v4/zones/' . $zoneId . '/rulesets/' . $res->id;
            $res = getCurl($getUrl, $email, $apiToken);
            
            if ($res['status'] == 'error') {
                echo json_encode(['status' => false, 'output' => $res['data']]);
                die;
            }
            $response = $res['data'];
            // getting rule names in array format for showing on the tickmark
            if ($response->success == true && isset($response->result->rules) && count($response->result->rules) > 0) {
                foreach($response->result->rules as $row) {
                    $rulesArray[] = $row->description;
                }
            }
        }
    }

    echo json_encode(['status' => true, 'output' => $rulesArray]);
    die;
}