<?php 
include('config.php');
include('curl.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/uikit.min.css" />
    <script src="js/uikit.min.js"></script>
    <script src="js/clipboard.min.js"></script>
    <script src="js/uikit-icons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@48,400,0,0" />

    
  <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"> -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

  <script type="text/javascript"src="js/common.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <div class="uk-container uk-margin-large-top">
        <legend class="uk-legend uk-margin-medium-bottom heading">Cloudflare Control</legend>
        <!-- Loader -->
            <div class="overlay"></div>
            
        <div id="errorMessage"></div>
        <div id="successMessage" ></div>
        <div class="uk-column-1@s uk-column-1-2@m uk-column-1-2@l uk-column-divider">   
            <fieldset class="uk-fieldset">
                <div class="uk-margin">
                    <input id = "account-email" class="uk-input input-field uk-form-width-large"  type="text" value="<?php echo $email; ?>" aria-label="Input"  placeholder="account email">
                </div>
                <div class="uk-margin">
                    <input id="api-token" class="uk-input input-field uk-form-width-large"  type="text" value="<?php echo $apiToken; ?>" aria-label="Input" placeholder="API Token">
                </div>
                <div class="uk-margin">
                    <input id="bearer-token" class="uk-input input-field uk-form-width-large"  type="text" value="<?php echo $bearer_token; ?>" aria-label="Input" placeholder="Bearer Token">
                </div>
                <div class="uk-margin">
                    <input name="name" class="uk-input input-field uk-form-width-large" id ="domainName" type="text" placeholder="Domain" aria-label="Input">
                    <span class="material-symbols-rounded" id="domainNameCheck"></span>
                </div>
                <input class="uk-button blue-btn uk-button-primary uk-margin-small-bottom" name="domainCheck" id="domainCheck" type="submit" value="Domain Check">
                
            </fieldset>  
            
            <input type ="hidden" id="zoneId" name="zoneId">
                <input type ="hidden" id="zoneName" name="zoneName" >
            
            <div class="uk-flex uk-flex-column">
                <div class="uk-flex button-field">
                    <input class="uk-button blue-btn uk-button-primary uk-margin-small-bottom" id="account-token" type="submit" value="Account token">
                </div>
                <div class="accountTokenDiv"style="display:none;">
                    <input class="uk-input input-field uk-form-width-medium"  style="width:500px;" id="accountTokenId" readonly type="text" aria-label="Input">
                    <div class="copyIcon" style="display:inline-block;">
                        <a class="copy-icon" data-tooltip-location="top" uk-icon="copy" data-placement="bottom" data-clipboard-target="#accountTokenId" onclick="copyToClipboard('#accountTokenId')"></a>
                    </div>
                </div>
                <br /><br />
                <div >
                    <input class="uk-input input-field uk-form-width-medium"  readonly="" type="text" aria-label="Input" style="border:0; background:none">
                    
                </div>
                <div class="overlay"></div>
                <div>
                    <input type="submit" name="xmlrpc" value="XMLRPC Block" class="ruleBtnClick uk-button blue-btn uk-button-primary uk-margin-small-bottom">
                    <span class="material-symbols-rounded" id="xmlrpc"></span>
                </div>
                <div><input type="submit" name="adminLogin" value="UK Admin / Login"  class="ruleBtnClick uk-button blue-btn uk-button-primary uk-margin-small-bottom">
                    <span class="material-symbols-rounded" id="adminLogin"></span>
                </div>
                <div><input type="submit" name="adminSecurity" value="Admin Security Check" class="ruleBtnClick uk-button blue-btn uk-button-primary uk-margin-small-bottom">
                    <span class="material-symbols-rounded" id="adminSecurity"></span>
                </div>
                <div><input type="submit" name="adminbypass" value="Admin Bypass" class="ruleBtnClick uk-button blue-btn uk-button-primary uk-margin-small-bottom">
                    <span class="material-symbols-rounded" id="adminbypass"></span>
                </div>
                <div><input type="submit" name="elasticMail" value="Elastic Mail Records" class="ruleBtnClick uk-button blue-btn uk-button-primary uk-margin-small-bottom">
                    <span class="material-symbols-rounded" id="elasticMail"></span>
                </div>
                <div><input type="submit" name="failover" value="Failover Protection" class="ruleBtnClick uk-button blue-btn uk-button-primary uk-margin-small-bottom">
                    <span class="material-symbols-rounded" id="failover"></span>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
