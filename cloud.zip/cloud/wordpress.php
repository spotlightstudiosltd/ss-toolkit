<?php 

include('config.php');
include('curl.php');

if (!empty($_POST['zoneId']) && !empty($_POST['zoneName'])) {
    $action = $_POST['action'];
    $email = $_POST['email'];
    $apiToken = $_POST['apiToken'];
    switch ($action) {
        case 'adminLogin':
            adminLogin($email, $apiToken);
            break;
        case 'xmlrpc';
            xmlrpcCheck($email, $apiToken);
            break;
        case 'adminSecurity';
            adminSecurity($email, $apiToken);
            break;
        case 'failover';
            failover($email, $apiToken);
            break;
        case 'adminbypass';
            adminbypass($email, $apiToken);
            break;
        case 'elasticMail';
            elasticMail($email, $apiToken, $DNSRecordsArray);
            break;
        default:
            # code...
            break;
    }
} else {
    $result = [
        'success'=>false,
        'message'=>'Zone details not available.'
    ];
    echo json_encode($result);
}
    

function adminLogin($email, $apiToken) {
    $ruleName = 'UK Admin / Login';
    $postParam = json_encode([
        "description" => "UK Admin / Login",
        "expression" => "(not ip.geoip.country in {\"GB\"} and http.request.uri eq \"/wp-login.php\")",
        "action" => "block",
        "enabled" => true
    ]);
    updateWafRule($_POST['zoneId'], $email, $apiToken, $ruleName, $postParam);
}

function xmlrpcCheck($email, $apiToken) {
    $ruleName = 'XMLRPC Block';
    $postParam = json_encode([
        "description" => "XMLRPC Block",
        "expression" => "(http.request.uri contains \"/xmlrpc.php\")",
        "action" => "block",
        "enabled" => true
    ]);
    updateWafRule($_POST['zoneId'], $email, $apiToken, $ruleName, $postParam);
}


function adminSecurity($email, $apiToken) {
    $ruleName = 'Admin Security Check';
    $postParam = json_encode([
        "description" => "Admin Security Check",
        "expression" => "(http.request.uri eq \"/wp-login.php\")",
        "action" => "managed_challenge",
        "enabled" => true
    ]);
    updateWafRule($_POST['zoneId'], $email, $apiToken, $ruleName, $postParam);
}


function failover($email, $apiToken) {
    $ruleName = 'Failover';
    $postParam = json_encode([
        "description" => "Failover",
        "expression" => "(http.request.uri contains \"failover.php\")",
        "action" => "block",
        "enabled" => true
    ]);
    updateWafRule($_POST['zoneId'], $email, $apiToken, $ruleName, $postParam);
}

function adminbypass($email, $apiToken) {
    $zoneId = $_POST['zoneId'];
    $email = $_POST['email'];
    $apiToken = $_POST['apiToken'];
    $url = "https://api.cloudflare.com/client/v4/zones/" . $zoneId . "/rulesets";
    $res = getCurl($url, $email, $apiToken);

    if ($res['status'] == 'error') {
        echo json_encode(['status' => false, 'output' => $res['data']]);
        die;
    }
    $rulesetList = $res['data']->result;
    $kindSearch = array_search('zone', array_column($rulesetList, 'kind'));
    $phaseSearch = array_search('http_request_cache_settings', array_column($rulesetList, 'phase'));
    if (count($res['data']->result) > 0 && !empty($kindSearch) && !empty($phaseSearch)) {
        foreach($rulesetList as $key => $res) {
            if ($res->kind == 'zone' && $res->phase == 'http_request_cache_settings') {
                $getUrl = 'https://api.cloudflare.com/client/v4/zones/' . $zoneId . '/rulesets/' . $res->id;
                $res = getCurl($getUrl, $email, $apiToken);
                if ($res['status'] == 'error') {
                    echo json_encode(['status' => false, 'output' => $res['data']]);
                    die;
                }
                $response = $res['data'];
                $rulesArray = [];
                if ($response->success == true && isset($response->result->rules) && count($response->result->rules) > 0) {
                    foreach($response->result->rules as $row) {
                        $rulesArray[] = $row->description;
                    }
                }
                
                if (in_array('Admin Bypass', $rulesArray)) {
                    echo json_encode(['status' => true, 'output' => 'Rules already exist.']);
                    die;
                } else {
                    $url = $getUrl . "/rules";
                    $headers = [
                        "Content-Type: application/json",
                        "X-Auth-Email: $email",
                        "X-Auth-Key: $apiToken"
                    ];
                    $postParam = json_encode([
                        "description" => "Admin Bypass",
                        "expression" => "(http.request.uri contains \"?swcfpc=1\") or (http.request.uri contains \"/wp-admin\")",
                        "action" => "set_cache_settings",
                        "enabled" => true,
                        "action_parameters" => [
                            "cache" => true
                        ]
                    ]);
                    postCurl($url, $postParam, $headers, 'POST');
                    echo json_encode(['status' => true, 'output' => 'Added successfully!']);
                    die;
                }
            }
        }
    } else {
        $ruleName = 'Admin Bypass';
        $url = 'https://api.cloudflare.com/client/v4/zones/' . $zoneId . '/rulesets';
        $createRulesetData = [
            'description' => 'My Cache Rule',
            "kind" => "zone",
            "name" => "My Cache ruleset",
            "phase" => "http_request_cache_settings",
            "rules" => [
                [
                    "description" => "Admin Bypass",
                    "expression" => "(http.request.uri contains \"?swcfpc=1\") or (http.request.uri contains \"/wp-admin\")",
                    "action" => "set_cache_settings",
                    "enabled" => true,
                    "action_parameters" => [
                        "cache" => true
                    ]
                ]
            ]
        ];
        $headers = [
            "Content-Type: application/json",
            "X-Auth-Email: $email",
            "X-Auth-Key: $apiToken"
        ];
        postCurl($url, json_encode($createRulesetData), $headers, 'POST');
        echo json_encode(['status' => true, 'output' => 'Added successfully!']);
        die;
    }
}

function elasticMail($email, $apiToken, $DNSRecordsArray) {
    $url = 'https://api.cloudflare.com/client/v4/zones/' . $_POST['zoneId'] . '/dns_records';
    $headers = [
        "Content-Type: application/json",
        "X-Auth-Email: $email",
        "X-Auth-Key: $apiToken"
    ];
    $spf_record = getCurl($url, $email, $apiToken);
    $dnsRecords = $spf_record['data']->result;
    
    $responseArray = [];
    if (count($dnsRecords) > 0) {
        for($i=0; $i<count($dnsRecords); $i++)  {
            $spf_content = explode(" ", $dnsRecords[$i]->content);
            if ($dnsRecords[$i]->name == $_POST['zoneName'] && $dnsRecords[$i]->type == 'TXT' && !in_array('include:_spf.elasticemail.com', $spf_content)) {
                array_splice($spf_content, count($spf_content)-1 ,0, 'include:_spf.elasticemail.com'); // added value in before the ~all word. 
                $updateUrl = $url . '/'. $dnsRecords[$i]->id;
                $updateParam = [
                    'name' => $dnsRecords[$i]->name,
                    'type' => 'TXT',
                    'content' =>  implode(' ', $spf_content),
                    'comment' => $dnsRecords[$i]->comment
                ];
                $res = postCurl($updateUrl, json_encode($updateParam), $headers, 'PUT');
                if ($res['status'] == 'error') {
                    echo json_encode(['status' => false, 'output' => $res['data']]);
                }
                $response = $res['data'];
                array_push($responseArray, '@');
            } else if ($dnsRecords[$i]->name == $_POST['zoneName'] && $dnsRecords[$i]->type == 'TXT' && in_array('include:_spf.elasticemail.com', $spf_content)) {
                array_push($responseArray, '@');
            }
        }

        foreach ($DNSRecordsArray as $row) {
            if (count($responseArray) > 0 && $row['name'] != '@') {
                $createRulesetData = [
                    "content" => $row['content'],
                    "name" => $row['name'],
                    "proxied" => $row['proxied'],
                    "type" => $row['type'],
                    "comment" => $row['comment'],
                ];
                $res = postCurl($url, json_encode($createRulesetData), $headers, 'POST');
                if ($res['status'] == 'error') {
                    echo json_encode(['status' => false, 'output' => $res['data']]);
                }
                $response = $res['data'];
                array_push($responseArray, $row['name']);
            } else if (count($responseArray) == 0 && !in_array('@', $responseArray)){
                $createRulesetData = [
                    "content" => $row['content'],
                    "name" => $row['name'],
                    "proxied" => $row['proxied'],
                    "type" => $row['type'],
                    "comment" => $row['comment'],
                ];
                $res = postCurl($url, json_encode($createRulesetData), $headers, 'POST');
                if ($res['status'] == 'error') {
                    echo json_encode(['status' => false, 'output' => $res['data']]);
                }
                $response = $res['data'];
                array_push($responseArray, $row['name']);
            } else if (count($responseArray) > 0 && !in_array('@', $responseArray) && $row['name'] == '@'){
                $createRulesetData = [
                    "content" => $row['content'],
                    "name" => $row['name'],
                    "proxied" => $row['proxied'],
                    "type" => $row['type'],
                    "comment" => $row['comment'],
                ];
                $res = postCurl($url, json_encode($createRulesetData), $headers, 'POST');
                if ($res['status'] == 'error') {
                    echo json_encode(['status' => false, 'output' => $res['data']]);
                }
                $response = $res['data'];
                array_push($responseArray, $row['name']);
            }
        }
    }

    if (!empty($responseArray) && count($responseArray) == 4) {
        echo json_encode(['status' => true, 'output' => 'are already exist']);
    } else {
        echo json_encode(['status' => true, 'output' => 'Added successfully!']);
    }
}

function updateWafRule($zoneId, $email, $apiToken, $ruleName, $postParam) {
    $url = "https://api.cloudflare.com/client/v4/zones/" . $zoneId . "/rulesets";
    $res = getCurl($url, $email, $apiToken);

    if ($res['status'] == 'error') {
        echo json_encode(['status' => false, 'output' => $res['data']]);
        die;
    }
    $rulesetList = $res['data']->result;
    $kindSearch = array_search('zone', array_column($rulesetList, 'kind'));
    $phaseSearch = array_search('http_request_firewall_custom', array_column($rulesetList, 'phase'));
    if (count($res['data']->result) > 0 && !empty($kindSearch) && !empty($phaseSearch)) {
        foreach($rulesetList as $key => $res) {
            if ($res->kind == 'zone' && $res->phase == 'http_request_firewall_custom') {
                $getUrl = 'https://api.cloudflare.com/client/v4/zones/' . $zoneId . '/rulesets/' . $res->id;
                $res = getCurl($getUrl, $email, $apiToken);
                if ($res['status'] == 'error') {
                    echo json_encode(['status' => false, 'output' => $res['data']]);
                    die;
                }
                $response = $res['data'];
                $rulesArray = [];
                if ($response->success == true && isset($response->result->rules) && count($response->result->rules) > 0) {
                    foreach($response->result->rules as $row) {
                        $rulesArray[] = $row->description;
                    }
                }
                
                if (in_array($ruleName, $rulesArray)) {
                    echo json_encode(['status' => true, 'output' => 'Rules already exist']);
                    die;
                } else {
                    $url = $getUrl . "/rules";
                    $headers = [
                        "Content-Type: application/json",
                        "X-Auth-Email: $email",
                        "X-Auth-Key: $apiToken"
                    ];
                    postCurl($url, $postParam, $headers, 'POST');
                    echo json_encode(['status' => true, 'output' => 'Added successfully!']);
                    die;
                }
            }
        }
    } else {
        $url = 'https://api.cloudflare.com/client/v4/zones/' . $zoneId . '/rulesets';
        $createRulesetData = [
            'description' => 'My ruleset to execute managed rulesets',
            "kind" => "zone",
            "name" => "My ruleset",
            "phase" => "http_request_firewall_custom",
            "rules" => json_decode($postParam)
        ];
        $headers = [
            "Content-Type: application/json",
            "X-Auth-Email: $email",
            "X-Auth-Key: $apiToken"
        ];
        postCurl($url, json_encode($createRulesetData), $headers, 'POST');
        echo json_encode(['status' => true, 'output' => 'Added successfully!']);
        die;
    }
}