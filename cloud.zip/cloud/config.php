<?php
   $apiToken = '840b3d3e6f701d6bdad8c1625ffbfd0bc800e';
   $email = 'thilipetp@gmail.com';
   $bearer_token ='Npbc2jiGiEFTlMXdMHem42hLb-2F8z-214L3b8Te';

   
// Now only using these DNS records so values set as static
$DNSRecordsArray = [
   [
       "content" => "k=rsa;t=s;p=MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCbmGbQMzYeMvxwtNQoXN0waGYaciuKx8mtMh5czguT4EZlJXuCt6V+l56mmt3t68FEX5JJ0q4ijG71BGoFRkl87uJi7LrQt1ZZmZCvrEII0YO4mp8sDLXC8g1aUAoi8TJgxq2MJqCaMyj5kAm3Fdy2tzftPCV/lbdiJqmBnWKjtwIDAQAB",
       "name" => "api._domainkey",
       "proxied" => false,
       "type" => "TXT",
       "comment" => "Record 2"
   ],
   [
       "content" => "v=spf1 a mx include:_spf.elasticemail.com ~all",
       "name" => "@",
       "proxied" => false,
       "type" => "TXT",
       "comment" => "Record 1"
   ],[
       "content" => "v=DMARC1;p=none;pct=100;aspf=r;adkim=r;",
       "name" => "_dmarc",
       "proxied" => false,
       "type" => "TXT",
       "comment" => "Record 3"
   ],[
       "content" => "api.elasticemail.com",
       "name" => "tracking",
       "proxied" => false,
       "type" => "CNAME",
       "comment" => "Record 4"
   ],

];
?>