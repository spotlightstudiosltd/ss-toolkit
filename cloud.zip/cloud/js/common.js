
// Once ajax is started loader is display on the screen
$(document).on({
    ajaxStart: function () {
        $('#errorMessage').html('');
        $('#successMessage').html('');
        $("body").addClass("loading");
    },
    ajaxStop: function () {
        // Once ajax is done loader is removed
        $("body").removeClass("loading");
    }
});

$(document).ready(function () {
    // tooltip is showing on the copy Clipboard
    var clipboard = new Clipboard('.copy-icon');

    clipboard.on('success', function (e) {
        var btn = $(e.trigger);
        setTooltip(btn, 'Copied');
        hideTooltip(btn);
    });
});
$(document).on('click', '#domainCheck', function (e) {
    e.preventDefault();
    clearFields();
    $('.accountTokenDiv').hide();
    if ($('#domainName').val() == '' || $('#api-token').val() == '' || $('#bearer-token').val() == '' || $('#account-email').val() == '') {
        $('#domainNameCheck').text('');
        $('#errorMessage').html('<div uk-alert class="uk-alert-warning">Please fill the Email, API token, Bearer Token and Domain name.<a class="uk-alert-close" uk-close></a></div>');
        showMessageDiv('#errorMessage');
    } else {
        $('#errorMessage').text('');
        $.ajax({
            method: 'POST',
            url: "domain-check-curl.php",
            data: {
                'url': 'https://api.cloudflare.com/client/v4/zones?name=' + $('#domainName').val(),
                'name': $('#domainName').val(),
                'email':$("#account-email").val(),
                'apiToken':$("#api-token").val(),
                'bearerToken':$("#bearer-token").val(),
            },
            cache: false,
            success: function (response) {
                var data = $.parseJSON(response);
                // Given domain is not matched it will return warning
                if (!data.status) {
                    $('#errorMessage').html('<div uk-alert class="uk-alert-warning">' + data.output +'<a class="uk-alert-close" uk-close></a></div>');
                    showMessageDiv('#errorMessage');
                    $('#domainNameCheck').text('close');
                    $('#domainNameCheck').css('color', 'red');
                } else {
                    if (data.output.length == 0) {
                        $('#errorMessage').html('<div uk-alert class="uk-alert-warning">Domain not exist<a class="uk-alert-close" uk-close></a></div>');
                        showMessageDiv('#errorMessage');
                        $('#domainNameCheck').text('close');
                        $('#domainNameCheck').css('color', 'red');
                    } else {
                        // Once zone is there it's set value for particular fields. otherwise it go to else part
                        // if (data.output.zoneId != '') {
                            $('#zoneId').val(data.output.zoneId);
                            $('#zoneName').val(data.output.zoneName);
                            $('#domainName').val(data.output.zoneName);
                            $('#domainNameCheck').text('done');
                            $('#domainNameCheck').css('color', 'green');
                            wafrules();
                            cacherules();
                            elasticmail();
                        // }
                    }
                }
            },
        });
    }
});
function wafrules() {
    $.ajax({
        method: 'POST',
        url: "waf_rules_list.php",
        data: {
            'zoneId': $("#zoneId").val(),
            'zoneName': $('#zoneName').val(),
            'email':$("#account-email").val(),
            'apiToken':$("#api-token").val(),
            'bearerToken':$("#bearer-token").val(),
        },
        cache: false,
        success: function (response) {
            var res = $.parseJSON(response);
            var data = res.output;
            var myNewArray = data.filter(function (elem, index, self) {
                return index === self.indexOf(elem);
            });
            $('#xmlrpc').text('');
            $('#adminLogin').text('');
            $('#adminSecurity').text('');
            $('#failover').text('');
            $.each(myNewArray, function (key, value) {
                if (value == 'XMLRPC Block') {
                    $('#xmlrpc').text('done');
                    $('#xmlrpc').css('color', 'green');
                } else if (value == 'UK Admin / Login') {
                    $('#adminLogin').text('done');
                    $('#adminLogin').css('color', 'green');
                } else if (value == 'Failover') {
                    $('#failover').text('done');
                    $('#failover').css('color', 'green');
                } else if (value == 'Admin Security Check') {
                    $('#adminSecurity').text('done');
                    $('#adminSecurity').css('color', 'green');
                }
            });
        },
    });
}

function cacherules() {
    $.ajax({
        method: 'POST',
        url: "cache_list.php",
        data: {
            'zoneId': $("#zoneId").val(),
            'zoneName': $('#zoneName').val(),
            'email':$("#account-email").val(),
            'apiToken':$("#api-token").val(),
            'bearerToken':$("#bearer-token").val(),
        },
        cache: false,
        success: function (response) {
            var res = $.parseJSON(response);
            var data = res.output;
            var myNewArray = data.filter(function (elem, index, self) {
                return index === self.indexOf(elem);
            });
            $('#adminbypass').text('');
            $.each(myNewArray, function (key, value) {
                if (value == 'Admin Bypass') {
                    $('#adminbypass').text('done');
                    $('#adminbypass').css('color', 'green');
                }
            });
        },
    });
}

function elasticmail() {
    $.ajax({
        method: 'POST',
        url: "elastic_mail_list.php",
        data: {
            'zoneId': $("#zoneId").val(),
            'zoneName': $('#zoneName').val(),
            'email':$("#account-email").val(),
            'apiToken':$("#api-token").val(),
            'bearerToken':$("#bearer-token").val(),
        },
        cache: false,
        success: function (response) {
            var res = $.parseJSON(response);
            var data = res.output;
            $('#elasticMail').text('');
            if (data.length == 4) {
                $('#elasticMail').text('done');
                $('#elasticMail').css('color', 'green');
            }
        },
    });
}
function clearFields() {

    $('#xmlrpc').text('');
    $('#adminLogin').text('');
    $('#failover').text('');
    $('#adminSecurity').text('');
    $('#adminbypass').text('');
    $('#elasticMail').text('');
    $('#zoneId').val('');
    $('#zoneName').val('');
    $('.accountTokenDiv').hide();
}
$(document).on('click', '#account-token', function (e) {
    e.preventDefault();
    if ($('#domainName').val() == '' || $('#api-token').val() == '' || $('#bearer-token').val() == '' || $('#account-email').val() == '') {
        $('#errorMessage').html('<div uk-alert class="uk-alert-warning">Please fill the Email, API token, Bearer Token and Domain name.<a class="uk-alert-close" uk-close></a></div>');
        showMessageDiv('#errorMessage');
    } else if ($('#zoneName').val() == '') {
        $('#errorMessage').html('<div uk-alert class="uk-alert-warning">Please provide a valid domain name and do a Domain check<a class="uk-alert-close" uk-close></a></div>');
        showMessageDiv('#errorMessage');
    } else {
        $('#errorMessage').text('');
        $.ajax({
            method: 'POST',
            url: "account-token.php",
            data: {
                'zoneId': $("#zoneId").val(),
                'zoneName': $('#zoneName').val(),
                'email':$("#account-email").val(),
                'apiToken':$("#api-token").val(),
                'bearerToken':$("#bearer-token").val(),
            },
            success: function (response) {
                var data = $.parseJSON(response);
                if (data.status) {
                    $('#accountTokenId').val(data.output);
                    $('.accountTokenDiv').show();
                } else {
                    $('#errorMessage').html('<div uk-alert class="uk-alert-warning">' + data.output + '<a class="uk-alert-close" uk-close></a></div>');
                    showMessageDiv('#errorMessage');
                }
            },
        });
    }
});
// if ($('#domainName').val() == '' || $('#api-token').val() == '' || $('#bearer-token').val() == '') 
$(document).on('change', '#domainName, #api-token, #bearer-token, #account-email', function (e) {
    // alert("test");
    clearFields();
});
$(document).on('click', '.ruleBtnClick', function (e) {
    var btnId = $(this).attr("name");
    var btnVal = $(this).val();
    e.preventDefault();
    if ($('#domainName').val() == '' || $('#api-token').val() == '' || $('#bearer-token').val() == '' || $('#account-email').val() == '') {
        $('#errorMessage').html('<div uk-alert class="uk-alert-warning">Please fill the Email, API token, Bearer Token and Domain name.<a class="uk-alert-close" uk-close></a></div>');
        showMessageDiv('#errorMessage');
    } else if ($('#zoneName').val() == '') {
        $('#errorMessage').html('<div uk-alert class="uk-alert-warning">Please provide a valid domain name and do a Domain check<a class="uk-alert-close" uk-close></a></div>');
        showMessageDiv('#errorMessage');
    } else {
        $('#errorMessage').text('');
        $.ajax({
            method: 'POST',
            url: "wordpress.php",
            data: {
                'zoneId': $("#zoneId").val(),
                'zoneName': $('#zoneName').val(),
                'action': btnId,
                'email':$("#account-email").val(),
                'apiToken':$("#api-token").val(),
                'bearerToken':$("#bearer-token").val(),
            },
            cache: false,
            success: function (response) {
                var data = $.parseJSON(response);
                if (data.status) {
                    $('#successMessage').html('<div uk-alert class="uk-alert-primary">' + btnVal + ' ' + data.output + '<a class="uk-alert-close" uk-close></a></div>');
                    showMessageDiv('#successMessage');
                } else {
                    $('#errorMessage').html('<div uk-alert class="uk-alert-warning">' + data.output + '<a class="uk-alert-close" uk-close></a></div>');
                    showMessageDiv('#errorMessage');
                }
                $('#' + btnId).text('done');
                $('#' + btnId).css('color', 'green');
            },
        });
    }
});

function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).val()).select();
    document.execCommand("copy");
    $temp.remove();
}

// Tooltip
$('.copy-icon').tooltip({
    trigger: 'click',
    placement: 'top'
});

function setTooltip(btn, message) {
    btn.tooltip('hide')
        .attr('data-tooltip', message)
        .tooltip('show');
}

function hideTooltip(btn) {
    setTimeout(function () {
        btn.tooltip('hide');
    }, 1000);
}

function showMessageDiv(btn) {
    $(btn).show();
    setTimeout(function () {
        $(btn).hide();
    }, 2500);
}