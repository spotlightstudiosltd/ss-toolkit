<?php 
include('curl.php');
include('config.php');
// Form value Processed
$url = $_POST['url'];
$email = $_POST['email'];
$apiToken = $_POST['apiToken'];

$res = getCurl($url, $email, $apiToken);

if ($res['status'] == 'error') {
    echo json_encode(['status' => false, 'output' => $res['data']]);
    die;
}
$data = $res['data'];

// Get the form values
$name = $_POST['name'];
$found = false;
if(isset($data->result) && !empty($data->result)){
    foreach ($data->result as $item) {
        if ($item->name === $name) {
            $found = true;
            break;
        }
    }
}


$data = [];
if ($found) {
   $data = [
        'zoneId' => $item->id,
        'zoneName' => $item->name
    ];
    echo json_encode(['status' => true, 'output' => $data]);
    die;
} else {
   echo json_encode(['status' => true, 'output' => $data]);
   die;
}
?>