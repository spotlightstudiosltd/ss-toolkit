<?php 

include('config.php');
include('curl.php');

$zoneId = '';
$zoneName = '';
if (!empty($_POST['zoneId']) && !empty($_POST['zoneName'])) {
    $zoneId = $_POST['zoneId'];
    $zoneName = $_POST['zoneName'];
    $bearer_token = $_POST['bearerToken'];
    // Now, Some permission groups only enabled here. Based on client requirement need to proceed some other permission enable later.
    $paramData = [
        "name" => $zoneName,
        "policies" => [
            [
                "effect" => "allow",
                "resources" => [
                    "com.cloudflare.api.account.*" => "*",
                    "com.cloudflare.api.account.zone.$zoneId" => "*"
                ],
                "permission_groups" => [
                    [
                        "id" => "c1fde68c7bcc44588cbb6ddbc16d6480",
                        "name" => "Account Settings Read"
                    ],
                    [
                        "id" => "e086da7e2179491d91ee5f35b3ca210a",
                        "name" => "Workers Scripts Write"
                    ],
                    [
                        "id" => "e17beae8b8cb423a99b1730f21238bed",
                        "name" => "Cache Purge"
                    ],
                    [
                        "id" => "ed07f6c337da4195b4e72a1fb2c6bcae",
                        "name" => "Page Rules Write"
                    ],
                    [
                        "id" => "3030687196b94b638145a3953da2b699",
                        "name" => "Zone Settings Write"
                    ],
                    [
                        "id" => "e6d2666161e84845a636613608cee8d5",
                        "name" => "Zone Write"
                    ],
                    [
                        "id" => "28f4b596e7d643029c524985477ae49a",
                        "name" => "Workers Routes Write"
                    ]
                ]
            ]
        ],
        "not_before" => "",
        "expires_on" => "",
        "condition" => [
            "request.ip" => [
                "in" => [],
                "not_in" => []
            ]
        ]
    ];
    $url = 'https://api.cloudflare.com/client/v4/user/tokens';
    $headers = [
        "Content-Type: application/json",
        "Authorization: Bearer $bearer_token"
    ];
    $res = postCurl($url, json_encode($paramData), $headers, 'POST');

    if ($res['status'] == 'error') {
        echo json_encode(['status' => false, 'output' => $res['data']]);
        die;
    }
    $data = $res['data'];

    if (!$data->success) {
        echo json_encode(['status' => false, 'output' => $data->errors[0]->message]);
        die;
    } else {
        // Access the "value" field from the JSON data
        $value = $data->result->value;
        echo json_encode(['status' => true, 'output' => $value]);
        die;
    }
} else {
    echo json_encode(['status' => false, 'output' => 'Zone details not available']);
    die;
}
?>