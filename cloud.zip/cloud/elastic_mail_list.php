<?php

include('config.php');
include('curl.php');

 $responseArray = [];
if (!empty($_POST['zoneId']) && !empty($_POST['zoneName'])) {
    $url = 'https://api.cloudflare.com/client/v4/zones/' . $_POST['zoneId'] . '/dns_records';
    
    $email = $_POST['email'];
    $apiToken = $_POST['apiToken'];
    $res = getCurl($url, $email, $apiToken);

    if ($res['status'] == 'error') {
        echo json_encode(['status' => false, 'output' => $res['data']]);
        die;
    }
    $response = $res['data']->result;

    $contents = array_column($DNSRecordsArray, 'content');
    $names = array_column($DNSRecordsArray, 'name');
    // getting DNS names in array format for showing on the tickmark
    for($i=0; $i <count($response); $i++) {
        $spf_content = explode(" ", $response[$i]->content);
        if (in_array($response[$i]->content, $contents)) {
            array_push($responseArray, $response[$i]->name);
        } else if ($response[$i]->name == $_POST['zoneName'] && $response[$i]->type == 'TXT' && in_array('include:_spf.elasticemail.com', $spf_content)) {
            array_push($responseArray, $response[$i]->name);
        }
    }
    echo json_encode(['status' => true, 'output' => $responseArray]);
    die;
}